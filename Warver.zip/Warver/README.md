# SELFBOT WAR ANTIJS AND AUTOKICK<br>
# JANGAN PERNAH SLAHGUNAKAN SC INI<br>
# BUAT YG MAU UBAH SILAHKAN UP SUKA SUAKA<br>
# TOTAL 8 AKUN 1SB+6ASIST+1AJS<br>
# SELFBOT INI MENGUNAKAN TOKEN CLOVAFRIEND V 5.5.1<br>
# UNTUK AMBIL TOKEN LANGSUNG DARI SC  BISA JUGA EMAIL<br>
# SUPORT BY: TBP [SILENTKILLER] TEAM BEBEK BOT,JUNSAN JUNIOR & ALL TEAM BOT<br>

# INSTALL MELALUI VPS<br>
========================================= <br>
sudo apt-get update<br>
sudo apt-get install git<br>
sudo apt-get install python3-pip<br>
sudo pip3 install rsa<br>
sudo pip3 install thrift==0.11.0<br>
sudo pip3 install requests<br>
sudo pip3 install pytz<br>
sudo pip3 install bs4<br>
sudo pip3 install gtts<br>
sudo pip3 install googletrans<br>
sudo pip3 install humanfriendly<br>
sudo pip3 install goslate<br>
sudo pip3 install pafy<br>
sudo pip3 install wikipedia<br>
sudo pip3 install tweepy<br>
sudo pip3 install youtube_dl<br>
git clone https://github.com/dhenza1415/WARDZ<br>
cd WARDZ<br>
ls<br>
pytho3 wardz.py<br>
======================================== <br>
# INSTALL MELALUI TERMUX<br>

pkg install python3 -y<br>
apt-get install python --upgrade<br>
pkg install git -y<br>
pkg install nano -y<br>
pip3 install rsa<br>
pip3 install thrift==0.11.0<br>
pip3 install requests<br>
pip3 install bs4<br>
pip3 install gtts<br>
pip3 install beautifulsoup<br>
pip3 install googletrans<br>
pip3 install pafy<br>
pip3 install humanfriendly<br>
pip3 install goslate<br>
pip3 install wikipedia<br>
pip3 install youtube_dl<br>
pip3 install tweepy<br>
pip3 install pytz<br>
pip3 install html5lib<br>
pip3 install pafy<br>
git clone https://github.com/dhenza1415/WARDZ<br>
ls<br>
cd WARDZ<br>
ls<br>
python3 wardz.py<br>

source : linepy by https://github.com/dhenza1415<br>
## Like dan subscribe chanel youtube :( https://youtu.be/CRqXKcTl6IY)<br>
## [SUBCRABE NOW](https://www.youtube.com/channel/UCNLejYy84XyUX8qcDropXMw)
KLIK
## [CREATOR](http://line.me/ti/p/~teambotprotect)
## .[FOLLOW AND STAR FOR GITHUB CREATOR](https://github.com/dhenza1415)

